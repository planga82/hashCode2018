package es.main;

public class Slice {

	int posRowIni;
	int posColIni;
	int rows;
	int cols;
	public Slice(int posRowIni, int posColIni, int rows, int cols) {
		super();
		this.posRowIni = posRowIni;
		this.posColIni = posColIni;
		this.rows = rows;
		this.cols = cols;
	}
	
	

	
	
	
	
}
