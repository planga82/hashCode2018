package es.main;

import java.util.ArrayList;

public class AssingVehicleRides {

	ArrayList<Integer> rides = new ArrayList<>();
	
}
