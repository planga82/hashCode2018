package es.main;

public class Escenario {

	int rows;
	int cols;
	int numVehicles;
	int numRides;
	int bonus;
	int steps;
	public Escenario(int rows, int cols, int numVehicles, int numRides, int bonus, int steps) {
		super();
		this.rows = rows;
		this.cols = cols;
		this.numVehicles = numVehicles;
		this.numRides = numRides;
		this.bonus = bonus;
		this.steps = steps;
	}
	
	
}
